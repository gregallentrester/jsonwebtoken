package net.greg.jwt.claims;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.BeforeEach;


public class PayloadTest {


  @Test  // worthwhile
  void constructorWithMap_getID() {

    Map<String, Object> map = new HashMap();

    map.put(Payload.Registered.ISSUER.getValue(), ISSUER);
    map.put(Payload.Registered.JWT_ID.getValue(), ID);

    payload = new Payload(map);

    assertThat(payload.getID(), is(ID));
  }


  @Test  // worthwhile
  void constructorWithMap_getIssuer() {

    Map<String, Object> map = new HashMap();

    map.put(Payload.Registered.ISSUER.getValue(), ISSUER);
    map.put(Payload.Registered.JWT_ID.getValue(), ID);

    payload = new Payload(map);

    assertThat(payload.getIssuer(), is(ISSUER));
  }


  @Test   // trivial
  void setIssuer() {
    payload.setIssuer(ISSUER);
    assertThat(payload.getIssuer(), is(ISSUER));
  }

  @Test   // trivial
  void setSubject() {
    payload.setSubject(SUBJECT);
    assertThat(payload.getSubject(), is(SUBJECT));
  }

  @Test   // trivial
  void setAudience() {
    payload.setAudience(AUDIENCE);
    String[] EXPECTED = { AUDIENCE };
    assertThat(payload.getAudience(), is(EXPECTED));
  }

  @Test   // trivial
  void setExpirationTime() {
    Date date = new Date(100);
    payload.setExpirationTime(date);
    assertThat(payload.getExpirationTime(), is(date));
  }

  @Test   // trivial
  void testSetExpirationTime() {
    payload.setExpirationTime(239872398);
    Date EXPECTED = new Date(239872398L);
    assertThat(payload.getExpirationTime(), is(EXPECTED));
  }

  @Test   // trivial
  void setNotBefore() {
    Date date = new Date(100);
    payload.setNotBefore(date);
    assertThat(payload.getNotBefore(), is(date));
  }

  @Test   // trivial
  void setIssuedAt() {
    Date date = new Date(100);
    payload.setIssuedAt(date);
    assertThat(payload.getIssuedAt(), is(date));
  }

  @Test   // trivial
  void setID() {
    payload.setID(ID);
    assertThat(payload.getID(), is(ID));
  }

  @Test   // trivial
  void base64EncodedWithEmptyPayload() {
    assertThat(payload.base64Encoded(), is(BASE_64_ENCODED_EMPTY));
  }

  @Test   // trivial
  void base64EncodedWithIssuer() {
    payload.setIssuer(ISSUER);
    assertThat(payload.base64Encoded(), is(BASE_64_ENCODED));
  }

  @Test   // trivial
  void getClaimAsString() {
    payload.addClaim(KEY, VALUE);
    assertThat(payload.getClaim(KEY, String.class), is(VALUE));
  }

  @Test   // trivial
  void getClaimAsInteger() {
    payload.addClaim(KEY, 100);
    int EXPECTED = 100;
    assertThat(payload.getClaim(KEY, Integer.class), is(EXPECTED));
  }

  @Test   // trivial
  void getClaimAsLong() {
    payload.addClaim(KEY, 100L);
    long EXPECTED = 100;
    assertThat(payload.getClaim(KEY, Long.class), is(EXPECTED));
  }

  @Test   // trivial
  void getCustomClaimAsDate() {
    Date date = new Date(100);
    payload.addClaim(KEY, date);
    assertThat(payload.getClaim(KEY, Date.class), is(date));
  }

  @Test   // trivial
  void getDateClaimAsDate() {
    Date date = new Date(100);
    payload.setNotBefore(date);
    assertThat(
      payload.getClaim(Payload.Registered.NOT_BEFORE.getValue(), Date.class),
      is(date));
  }

  @Test   // trivial
  void getClaimConverted() {
    payload.addClaim(KEY, VALUE);
    assertThat(payload.getClaim(KEY, value ->
      String.valueOf(value).toUpperCase()), is(VALUE_UPPERCASE));
  }

  @Test   // trivial
  void getClaimLongConvertedToDate() {
    payload.addClaim(KEY, 100);
    Date EXPECTED = new Date(100);
    assertThat(payload.getClaim(KEY, value -> {
      long millis = Long.parseLong(String.valueOf(value));

      return new Date(millis);
    }), is(EXPECTED));
  }



  private static final String BASE_64_ENCODED = "eyJpc3MiOiJpc3N1ZXIifQ";
  private static final String BASE_64_ENCODED_EMPTY = "e30";

  private static final String KEY = "key";
  private static final String VALUE_UPPERCASE = "VALUE";

  private static final String NAME = "name";
  private static final String VALUE = "value";

  private static final String TEST = "test";
  private static final String INVALID = "invalid";

  private static final String AUDIENCE = "audience";

  private static final String AUD1 = "aud1";
  private static final String AUD2 = "aud2";
  private static final String AUD3 = "aud3";

  private static final String ID = "id";

  private static final String SUBJECT = "subject";
  private static final String ISSUER = "issuer";

  private static final String TYPE = "type";
  private static final String CONTENT_TYPE = "content-type";

  private static final String SECRET = "secret";
  private static final String JWT = "JWT";

  private static final String ALGO_HS384 = "HS384";

  private static final String CUSTOM_HEADER = "custom-header";
  private static final String CUSTOM_HEADER_VALUE = "custom-header-value";

  private static final String CUSTOM_CLAIM = "custom-claim";
  private static final String CUSTOM_CLAIM_VALUE = "custom-claim-value";

  private static final String CUSTOM_PAYLOAD = "custom-payload";
  private static final String CUSTOM_PAYLOAD_VALUE = "custom-payload-value";



  private Payload payload;


  @BeforeEach
  void setUp() { payload = new Payload(); }


  @AfterEach
  void tearDown() { payload = null; }
}
