package net.greg.jwt;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

import org.junit.jupiter.api.*;

import org.junit.jupiter.api.function.Executable;

import net.greg.jwt.algorithms.Algorithm;

import net.greg.jwt.claims.*;


public class TokenTest {


  @Test
  void builder_doesNotThrow() {

    assertDoesNotThrow(() ->
      new Token.Builder(ALGORITHM).build());
  }


  @Test
  void builder_withType() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).
        withType(TYPE).build();

    assertThat(token.getHeader().getType(), is(TYPE));
  }


  @Test
  void builder_withAlgorithm() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).build();

    assertThat(token.getAlgorithm(), is(ALGORITHM));
  }


  @Test
  void builder_withContentType() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).
      withContentType(CONTENT_TYPE).build();

    assertThat(token.getHeader().getContentType(), is(CONTENT_TYPE));
  }


  @Test
  void builder_withID() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).
        withID(ID).build();

    assertThat(token.getPayload().getID(), is(ID));
  }


  @Test
  void builder_withIssuer() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).
        withIssuer(ISSUER).build();

    assertThat(token.getPayload().getIssuer(), is(ISSUER));
  }


  @Test
  void builder_withEmptyAudience() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).
        withAudience().build();

    String[] EXPECTED = { };

    assertThat(token.getPayload().getAudience(), is(EXPECTED));
  }


  @Test
  void builder_withAudience() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).
        withAudience(AUD1, AUD2).build();

    String[] EXPECTED = { AUD1, AUD2 };

    assertThat(token.getPayload().getAudience(), is(EXPECTED));
  }


  @Test
  void builder_withSubject() throws Exception {

    Token token = new Token.Builder(ALGORITHM).
      withSubject(SUBJECT).build();

    assertThat(token.getPayload().getSubject(), is(SUBJECT));
  }


  @Test
  void builder_withIssuedAt() throws Exception {

    Date now = new Date();

    Token token =
      new Token.Builder(ALGORITHM).
        withIssuedAt(now).build();

    assertThat(token.getPayload().getIssuedAt(), is(now));
  }


  @Test
  void builder_withNotBefore() throws Exception {

    Date now = new Date();

    Token token =
      new Token.Builder(ALGORITHM).
        withNotBefore(now).build();

    assertThat(token.getPayload().getNotBefore(), is(now));
  }


  @Test
  void builder_withExpirationTime() throws Exception {

    Date now = new Date();

    Token token =
      new Token.Builder(ALGORITHM).
        withExpirationTime(now).build();

    assertThat(token.getPayload().getExpirationTime(), is(now));
  }


  @Test
  void builder_withClaim() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).
        withClaim(CUSTOM_CLAIM, CUSTOM_CLAIM_VALUE).build();

    assertThat(
      token.getPayload().
        getClaim(CUSTOM_CLAIM, String.class), is(CUSTOM_CLAIM_VALUE));
  }


  @Test
  void builder_withHeader() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).
        withHeader(CUSTOM_HEADER, CUSTOM_HEADER_VALUE).build();

    assertThat(token.getHeader().getClaim(CUSTOM_HEADER, String.class), is(CUSTOM_HEADER_VALUE));
  }


  @Test
  void builder_withCustomHeader() throws Exception {

    Header header = new Header();

    Token token =
      new Token.Builder(ALGORITHM).
        withHeader(header).build();

    assertThat(token.getHeader(), is(header));
  }


  @Test
  void builder_withCustomPayload() throws Exception {

    Payload payload = new Payload();

    Token token =
      new Token.Builder(ALGORITHM).withPayload(payload).build();

    assertThat(token.getPayload(), is(payload));
  }


  @Test
  void builderWithHeaderNameIsNull_throwsIllegalArgument() {

    Token.Builder builder =
      new Token.Builder(ALGORITHM);

    assertThrows(IllegalArgumentException.class, () ->
      builder.withHeader(null, VALUE));
  }


  @Test
  void builderWithHeaderValueIsNull_throwsIllegalArgument() {

    Token.Builder builder =
      new Token.Builder(ALGORITHM);

    assertThrows(IllegalArgumentException.class, () ->
      builder.withHeader(NAME, null));
  }


  @Test
  void builderWithClaimValueIsNull_throwsIllegalArgument() {

    Token.Builder builder =
      new Token.Builder(ALGORITHM);

    assertThrows(IllegalArgumentException.class, () ->
      builder.withClaim(NAME, null));
  }


  @Test
  void builderAlgorithmIsNull_throwsIllegalArgument() {

    assertThrows(IllegalArgumentException.class, () ->
      new Token.Builder(null));
  }


  @Test
  void fromRawToken_doesNotThrow() {

    assertDoesNotThrow(() ->
      Token.fromRawToken(ALGORITHM, TOKEN_STRING));
  }


  @Test
  void fromRawToken_typeIsToken() throws Exception {

    Token token =
      Token.fromRawToken(ALGORITHM, TOKEN_STRING);

    assertThat(token.getHeader().getType(), is(JWT));
  }


  @Test
  void fromRawToken_algorithmIsHS384() throws Exception {

    Token token =
      Token.fromRawToken(ALGORITHM, TOKEN_STRING);

    assertThat(token.getHeader().getAlgorithm(), is(ALGO_HS384));
  }


  @Test
  void fromRawToken_issuer() throws Exception {

    Token token =
      Token.fromRawToken(ALGORITHM, TOKEN_STRING);

    assertThat(token.getPayload().getIssuer(), is(ISSUER));
  }


  @Test
  void fromRawToken_audience() throws Exception {

    Token token =
      Token.fromRawToken(ALGORITHM, TOKEN_STRING);

    String[] EXPECTED = { AUDIENCE };

    assertThat(token.getPayload().getAudience(), is(EXPECTED));
  }


  @Test
  void fromRawToken_id() throws Exception {

    Token token =
      Token.fromRawToken(ALGORITHM, TOKEN_STRING);

    assertThat(token.getPayload().getID(), is(ID));
  }


  @Test
  void fromRawToken_issuedAt() throws Exception {

    Token token =
      Token.fromRawToken(ALGORITHM, TOKEN_STRING);

    assertThat(token.getPayload().getIssuedAt(), is(new Date(1614676926172L)));
  }


  @Test
  void fromRawMalformedToken_throwsException() {

    assertThrows(Exception.class, () ->
      Token.fromRawToken(ALGORITHM, MALFORMED_TOKEN));
  }


  @Test
  void fromRawTokenWithTwoSegments_throwsException() {

    String token = SEGMENT1_SEGMENT2;

    assertThrows(Exception.class, () ->
      Token.fromRawToken(ALGORITHM, token));
  }


  @Test
  void fromRawTokenWithOneSegments_throwsException() {

    String token = SEGMENT1;

    assertThrows(Exception.class, () ->
      Token.fromRawToken(ALGORITHM, token));
  }


  @Test
  void fromRawTokenWithEmptyString_throwsException() {

    String token = "";

    assertThrows(Exception.class, () ->
      Token.fromRawToken(ALGORITHM, token));
  }


  @Test
  void validate_doesNotThrow() throws Exception {

    Token token =
      new Token.Builder(ALGORITHM).build();

    assertDoesNotThrow((Executable) token::validate);
  }


  @Test
  void sign_doesNotThrow() {

    assertDoesNotThrow(() ->
      new Token.Builder(ALGORITHM).sign());
  }


  @Test
  void signWithCustomPayload_doesNotThrow() {

    Map<String, String> payload =
      new HashMap();

    payload.put(CUSTOM_PAYLOAD, CUSTOM_PAYLOAD_VALUE);

    assertDoesNotThrow(() ->
      new Token.Builder(ALGORITHM).sign(payload));
  }


  @Test
  void sign() throws Exception {

    String token =
      new Token.Builder(ALGORITHM).sign();

    assertThat(token, is(VALID_TOKEN));
  }


  @Test
  void sign_tokenHasThreeSegments() throws Exception {

    String token =
      new Token.Builder(ALGORITHM).sign();

    int EXPECTED = 3;

    assertThat(token.split("\\.").length, is(EXPECTED));
  }


  private static final String SEGMENT1 = "segment1";
  private static final String SEGMENT1_SEGMENT2 = "segment1.segment2";


  private static final String MALFORMED_TOKEN =
  "eyJhbGciOiJIUzM4NCIssdsdjkhInR5cCI6IkpXVCJ9shdkshdsdssdljs.eyJpc3MiOiJpc3N1ZXIiLCJhdWQiOiJhdWRpZW5jZSIsImlhdCI6MTYxNDY3NjkyNjE3MiwianRpIjoiaWQifQ.ibsMduBXhE8Y1TkDAazH-J7BaAtcJTcwmHfzvQg9EWS6uKZFsA_7z4LYtSa-nnR1";


  private static final String VALID_TOKEN =
    "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.e30.nx2GHSOLOGjofcETRXDMFQfkhN3YB-B5WMieLPkIM0MazzxtHN0YpuV5OMyQvx3r";


  private static final String NAME = "name";
  private static final String VALUE = "value";

  private static final String TEST = "test";
  private static final String INVALID = "invalid";

  private static final String AUDIENCE = "audience";

  private static final String AUD1 = "aud1";
  private static final String AUD2 = "aud2";
  private static final String AUD3 = "aud3";

  private static final String ID = "id";

  private static final String SUBJECT = "subject";
  private static final String ISSUER = "issuer";

  private static final String TYPE = "type";
  private static final String CONTENT_TYPE = "content-type";

  private static final String SECRET = "secret";
  private static final String JWT = "JWT";

  private static final String ALGO_HS384 = "HS384";

  private static final String CUSTOM_HEADER = "custom-header";
  private static final String CUSTOM_HEADER_VALUE = "custom-header-value";

  private static final String CUSTOM_CLAIM = "custom-claim";
  private static final String CUSTOM_CLAIM_VALUE = "custom-claim-value";

  private static final String CUSTOM_PAYLOAD = "custom-payload";
  private static final String CUSTOM_PAYLOAD_VALUE = "custom-payload-value";



  private Algorithm ALGORITHM;
  private String TOKEN_STRING;


  @BeforeEach
  void setUp() {

    ALGORITHM = Algorithm.HMAC384(SECRET);

    TOKEN_STRING =          "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJpc3N1ZXIiLCJhdWQiOiJhdWRpZW5jZSIsImlhdCI6MTYxNDY3NjkyNjE3MiwianRpIjoiaWQifQ.ibsMduBXhE8Y1TkDAazH-J7BaAtcJTcwmHfzvQg9EWS6uKZFsA_7z4LYtSa-nnR1";
  }


  @AfterEach
  void tearDown() {
    ALGORITHM = null;
    TOKEN_STRING = null;
  }
}
