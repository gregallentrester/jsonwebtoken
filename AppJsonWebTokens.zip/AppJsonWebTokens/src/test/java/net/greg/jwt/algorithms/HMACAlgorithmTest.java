package net.greg.jwt.algorithms;


import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Base64;

import org.junit.jupiter.api.*;


public class HMACAlgorithmTest {


  @Test
  void sign_doesNotThrow() {
    assertDoesNotThrow(() ->
    algorithm.sign(DATA.getBytes()));
  }

  @Test
  void sign() throws Exception {

    byte[] signed =
      algorithm.sign(DATA.getBytes());

    String signedBase64URLEncoded =
      Base64.getUrlEncoder().encodeToString(signed);

    assertThat(signedBase64URLEncoded, is(VALID_SIGNED_BASE_64_URL_ENCODED));
  }

  @Test
  void signWithString_doesNotThrow() {
    assertDoesNotThrow(() -> algorithm.sign(DATA));
  }

  @Test
  void signWithString() throws Exception {

    byte[] signed =
      algorithm.sign(DATA);

    String signedBase64URLEncoded =
      Base64.getUrlEncoder().withoutPadding().encodeToString(signed);

    assertThat(signedBase64URLEncoded, is(SIGNED_BASE_64_URL_ENCODED));
  }

  @Test
  void verify_doesNotThrow() {

    assertDoesNotThrow(() -> {

        algorithm.verify(
          DATA.getBytes(),
          Base64.getUrlDecoder().
            decode(OK_TOKEN));
    });
  }


  @Test
  void verifyExpectedIsCorrect() throws Exception {

    boolean isValid =
      algorithm.verify(
        DATA.getBytes(),
        Base64.getUrlDecoder().
          decode(CORRECT_TOKEN));

    assertThat(isValid, is(true));
  }


  @Test
  void verifyExpectedIsIncorrect() throws Exception {

    boolean isValid =
      algorithm.verify(
      DATA.getBytes(),
      Base64.getUrlDecoder().
        decode(INCORRECT_TOKEN));

    assertThat(isValid, is(false));
  }


  private static final String VALID_SIGNED_BASE_64_URL_ENCODED =
    "zbOa_v86tCj1m7nx3ZGDEq6urhQ4ROmcKbXcbQjK-U8=";

  private static final String SIGNED_BASE_64_URL_ENCODED =
    "zbOa_v86tCj1m7nx3ZGDEq6urhQ4ROmcKbXcbQjK-U8";



  private static final String OK_TOKEN =
    "zbOa_v86tCj1m7nx3ZGDEq6urhQ4ROmcKbXcbQjK-U8";

  private static final String CORRECT_TOKEN =
    "zbOa_v86tCj1m7nx3ZGDEq6urhQ4ROmcKbXcbQjK-U8";

  private static final String INCORRECT_TOKEN =
    "zbOa_v86tCj1m7nx3ZGDEq6urhQ4ROmcKbXcbQjK-U";



  private static final String HS512 =
    "HS512";

  private static final String HMAC_SHA_256 =
    "HmacSHA256";

  private static final String DATA = "data";



  private HMACAlgorithm algorithm;

  @BeforeEach
  void setUp() {

    algorithm =
      new HMACAlgorithm(
        HS512,                                  // name
        HMAC_SHA_256,                           // description
        "KKSDSDBSJDBAPKSDHYUSD".getBytes());    // secret
  }

  @AfterEach
  void tearDown() { algorithm = null; }
}
