package net.greg.jwt.claims;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class HeaderTest {


  @Test
  void constructor_typeIsByDefaultJWT() {
    assertThat(header.getType(), is(JWT));
  }


  @Test
  void constructorWithMap_getType() {

    Map<String, Object> map =
      new HashMap();

    map.put(Claims.Registered.TYPE.getValue(), TYPE);
    map.put(Claims.Registered.ALGORITHM.getValue(), ALGO_WITH_MAP);

    String EXPECTED = TYPE;

    header = new Header(map);

    assertThat(header.getType(), is(EXPECTED));
  }


  @Test
  void constructorWithMap_getAlgorithm() {

    Map<String, Object> map = new HashMap();

    map.put(Claims.Registered.TYPE.getValue(), TYPE);
    map.put(Claims.Registered.ALGORITHM.getValue(), ALGO_WITH_MAP);


    header = new Header(map);

    assertThat(header.getAlgorithm(), is(ALGO_WITH_MAP));
  }


  @Test
  void setType() {

    header.setType(TYPE);

    assertThat(header.getType(), is(TYPE));
  }


  @Test
  void setContentType() {

    header.setContentType(CONTENT_TYPE);

    assertThat(header.getContentType(), is(CONTENT_TYPE));
  }


  @Test
  void setAlgorithm() {

    header.setAlgorithm(ALGORITHM);

    assertThat(header.getAlgorithm(), is(ALGORITHM));
  }


  @Test
  void base64EncodedWithDefaultHeader() {

    assertThat(header.base64Encoded(), is(BASE_64_ENCODED_WITH_DEFAULT_HEADER));
  }


  @Test
  void base64EncodedWithType() {

    header.setType(TYPE);

    assertThat(header.base64Encoded(), is(BASE_64_ENCODED_WITH_TYPE));
  }


  private static final String ALGORITHM = "algorithm";

  private static final String TYPE = "type";
  private static final String BASE_64_ENCODED_WITH_TYPE = "eyJ0eXAiOiJ0eXBlIn0";

  private static final String CONTENT_TYPE = "content-type";

  private static final String  BASE_64_ENCODED_WITH_DEFAULT_HEADER = "eyJ0eXAiOiJKV1QifQ";

  private static final String JWT = "JWT";

  private static final String ALGO_WITH_MAP = "HS512";


  private Header header;


  @BeforeEach
  void setUp() { header = new Header(); }


  @AfterEach
  void tearDown() { header = null; }
}
