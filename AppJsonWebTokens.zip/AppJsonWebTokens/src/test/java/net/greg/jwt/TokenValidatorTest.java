package net.greg.jwt;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Instant;
import java.util.Date;

import org.junit.jupiter.api.*;

import net.greg.jwt.algorithms.Algorithm;


public final class TokenValidatorTest {


  @Test
  void validate_noThrow() throws Exception {

    Token token = new Token.Builder(algorithm).build();

    assertDoesNotThrow(() ->
      new TokenValidator().validate(token));
  }


  @Test
  void withInvalidSignature_throwsException() throws Exception, Exception {

    String jwtString = "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJpc3N1ZXIiLCJhdWQiOiJhdWRpZW5jZSIsImlhdCI6MTYxNDY3NjkyNjE3MiwianRpIjoiaWQifQ.ibsMduBXhE8Y1TkDAazH-J7BaAtcJTcwmHfzvQg9EWS6uKZFsA_7z4LYtSa-nnR";

    Token token = Token.fromRawToken(algorithm, jwtString);

    assertThrows(Exception.class, () ->
      new TokenValidator().validate(token));
  }


  @Test
  void withExpirationTimeInPast_throwsException() throws Exception {

    Date past = new Date(100);

    Token token =
      new Token.Builder(algorithm).
        withExpirationTime(past).build();

    assertThrows(Exception.class, () ->
      new TokenValidator().validate(token));
  }


  @Test
  void withExpirationTimeInFuture_noThrow() throws Exception {

    Date future =
      Date.from(Instant.
        now().plusSeconds(1000));

    Token token =
      new Token.Builder(algorithm).
        withExpirationTime(future).build();

    assertDoesNotThrow(() ->
      new TokenValidator().validate(token));
  }


  @Test
  void withValidType_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withType(JWT).build();

    assertDoesNotThrow(() ->
      new TokenValidator().validate(token));
  }


  @Test
  void withInvalidType_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withType(TYPE).build();

    assertThrows(Exception.class, () ->
      new TokenValidator().validate(token));
  }


  @Test
  void withInvalidContentType_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withContentType(INVALID).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withContentType(CONTENT_TYPE).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidContentType_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withContentType(CONTENT_TYPE).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withContentType(CONTENT_TYPE).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withInvalidAlgorithm_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withAlgorithm(INVALID).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidAlgorithm_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withAlgorithm(ALGO_HS384).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withInvalidIssuer_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).withIssuer(ISSUER).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withIssuer(INVALID).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidIssuer_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withIssuer(ISSUER).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withIssuer(ISSUER).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withInvalidSubject_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).withSubject(SUBJECT).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withSubject(INVALID).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidSubject_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).withSubject(ISSUER).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withSubject(ISSUER).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withInvalidAudience_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withAudience(AUD1, AUD2).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withOneOfAudience(INVALID).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidAudience_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withAudience(AUD1, AUD2).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withOneOfAudience(AUD1).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withValidAllAudience_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withAudience(AUD1, AUD2, AUD3).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withAllOfAudience(AUD1, AUD2).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withValidAllAudience_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withAudience(AUD1, AUD3).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withAllOfAudience(AUD1, AUD2).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withInvalidExpirationDate_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withExpirationTime(100).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withExpirationTime(200).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidExpirationDate_noThrow() throws Exception {

    Date date =
      Date.from(Instant.
        now().plusSeconds(100));

    Token token =
      new Token.Builder(algorithm).
        withExpirationTime(date).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withExpirationTime(date).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withInvalidNotBefore_throwsException() throws Exception {

    final int TOMORROW_SECONDS_DISPLACEMENT = 86_400;

    Date tomorrow =
      Date.from(Instant.
        now().plusSeconds(TOMORROW_SECONDS_DISPLACEMENT));

    Date now = Date.from(Instant.now());


  System.err.println(
    "\n\n Expect VIOLATION" +
    " | withInvalidNotBefore_throwsException()" +
    "\n\n -------->>--->>> tomorrow " + tomorrow +
    "\n -------->>--->>>    today " + now + "\n\n");

    Token token =
      new Token.Builder(algorithm).
        withNotBefore(tomorrow).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withNotBefore(tomorrow).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidNotBefore_noThrow() throws Exception {

    final int YESTERDAY_SECONDS_DISPLACEMENT = 86_400;

    Date yesterday =
      Date.from(Instant.
        now().minusSeconds(YESTERDAY_SECONDS_DISPLACEMENT));

    Date now = Date.from(Instant.now());


    System.err.println(
      "\n\n Expect COMPLIANCE" +
      " | withValidNotBefore_noThrow()" +
      "\n\n -------->>--->>> yesterday " + yesterday +
      "\n -------->>--->>>     today " + now + "\n\n");


    Token token =
      new Token.Builder(algorithm).
        withNotBefore(yesterday).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withNotBefore(yesterday).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withInvalidIssuedAt_throwsException() throws Exception {

    Date date = new Date(100);

    Token token =
      new Token.Builder(algorithm).
        withIssuedAt(date).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withIssuedAt(200).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidIssuedAt_noThrow() throws Exception {

    Date date = new Date(100);

    Token token =
      new Token.Builder(algorithm).
        withNotBefore(date).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withNotBefore(date).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withInvalidID_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withID(ID).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withID(INVALID).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withValidID_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withID(ID).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withID(ID).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withHeader_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withHeader(TEST, VALUE).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withHeader(TEST, VALUE::equals).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withHeader_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withHeader(TEST, VALUE).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withHeader(TEST, INVALID::equals).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withClaim_noThrow() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withClaim(TEST, VALUE).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withClaim(TEST, VALUE::equals).build();

    assertDoesNotThrow(() ->
      validator.validate(token));
  }


  @Test
  void withClaim_throwsException() throws Exception {

    Token token =
      new Token.Builder(algorithm).
        withClaim(TEST, VALUE).build();

    TokenValidator validator =
      new TokenValidator.Builder().
        withClaim(TEST, INVALID::equals).build();

    assertThrows(Exception.class, () ->
      validator.validate(token));
  }


  @Test
  void withHeaderNameIsNull_throwsIllegalArgumentException() {

    assertThrows(IllegalArgumentException.class, () ->
      new TokenValidator.Builder().
        withHeader(null, VALUE).build());
  }


  @Test
  void withHeaderValueIsNull_throwsIllegalArgumentException() {

    assertThrows(IllegalArgumentException.class, () ->
      new TokenValidator.Builder().
        withHeader(NAME, null).build());
  }


  @Test
  void withCustomHeaderNameIsNull_throwsIllegalArgumentException() {

    assertThrows(IllegalArgumentException.class, () ->
      new TokenValidator.Builder().
        withHeader(null, value -> false).build());
  }


  @Test
  void withCustomHeaderValidatorIsNull_throwsIllegalArgumentException() {

    assertThrows(IllegalArgumentException.class, () ->
      new TokenValidator.Builder().
        withHeader(NAME, null).build());
  }


  @Test
  void withClaimNameIsNull_throwsIllegalArgumentException() {

    assertThrows(IllegalArgumentException.class, () ->
      new TokenValidator.Builder().
        withClaim(null, VALUE).build());
  }


  @Test
  void withClaimValueIsNull_throwsIllegalArgumentException() {

    assertThrows(IllegalArgumentException.class, () ->
      new TokenValidator.Builder().
        withClaim(NAME, null).build());
  }


  @Test
  void withCustomClaimNameIsNull_throwsIllegalArgumentException() {

    assertThrows(IllegalArgumentException.class, () ->
      new TokenValidator.Builder().
        withClaim(null, value -> false).build());
  }


  @Test
  void withCustomClaimValidatorIsNull_throwsIllegalArgumentException() {

    assertThrows(IllegalArgumentException.class, () ->
      new TokenValidator.Builder().
        withClaim(NAME, null).build());
  }


  private static final String NAME = "name";
  private static final String VALUE = "value";

  private static final String TEST = "test";
  private static final String INVALID = "invalid";

  private static final String AUD1 = "aud1";
  private static final String AUD2 = "aud2";
  private static final String AUD3 = "aud3";

  private static final String ID = "id";

  private static final String SUBJECT = "subject";
  private static final String ISSUER = "issuer";

  private static final String TYPE = "type";
  private static final String CONTENT_TYPE = "content-type";

  private static final String SECRET = "secret";
  private static final String JWT = "JWT";

  private static final String ALGO_HS384 = "HS384";



  private Algorithm algorithm;


  @BeforeEach
  void setUp() { algorithm = Algorithm.HMAC384(SECRET); }


  @AfterEach
  void tearDown() { algorithm = null; }
}
