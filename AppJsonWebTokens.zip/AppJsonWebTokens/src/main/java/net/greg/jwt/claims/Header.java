package net.greg.jwt.claims;

import java.util.Map;
import org.json.JSONObject;
import net.greg.jwt.utils.Base64Utils;

/**
 * A Claim of type Header
 */
public final class Header extends Claims {

  /**
   * No-args constructor
   */
  public Header() {

    setType("JWT");
  }

  /**
   * constructor
   *
   * @param map dictionary of Header Claims to be registered
   */
  public Header(Map<String, Object> map) {

    this();
    claims.putAll(map);
  }

  /**
   * Create a Header that is derived from a base64-Encoded JSON (String)
   *
   * @param encodedJSON derive a Header from a base64-Encoded JSON (String)
   * @return Header the Header dervied from a base64-Encoded JSON (String)
   */
  public static Header fromBase64EncodedJSON(String encodedJSON) {

    String decodedJSON =
      Base64Utils.decodeBase64URL(encodedJSON);

    Map<String, Object> map =
      new JSONObject(decodedJSON).toMap();

    return new Header(map);
  }

  /**
   * Mutator for the type (String) Claim attribute
   *
   * @param type mutate the 'typ' Claim from a String value
   */
  public void setType(String type) {
    addClaim(Registered.TYPE.getValue(), type);
  }

  /**
   * Accessor for the type (String) Claim attribute
   *
   * @return String
   */
  public String getType() {
    return getClaim(Registered.TYPE.getValue(), String.class);
  }

  /**
   * Mutator for the content-type (String) Claim attribute
   *
   * @param value mutate the algorithm Claim from a String value
   */
  public void setContentType(String value) {
    addClaim(Registered.CONTENT_TYPE.getValue(), value);
  }

  /**
   * Accessor for the content-type (String) Claim attribute
   *
   * @return String
   */
  public String getContentType() {
    return getClaim(Registered.CONTENT_TYPE.getValue(), String.class);
  }

  /**
   * Mutator for the Algorithm used by the Claim
   *
   * @param algorithm mutate the 'algo' Claim from a String value
   */
  public void setAlgorithm(String algorithm) {
    addClaim(Registered.ALGORITHM.getValue(), algorithm);
  }

  /**
   * Accessor for the Algorithm used by the Claim
   *
   * @return String
   */
  public String getAlgorithm() {
    return getClaim(Registered.ALGORITHM.getValue(), String.class);
  }
}
