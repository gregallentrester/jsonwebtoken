package net.greg.jwt.algorithms;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;


/**
 * Abstract API for concrete cryptographic signature classes
 */
public abstract class Algorithm {

  /**
   * Default constructor for concrete cryptographic signature classes
   *
   * @param moniker name of the algorith
   * @param desc description of the algorith
   */
  Algorithm(String moniker, String desc) {
    name = moniker;
    description = desc;
  }


  /**
   * Factory constructor for an HMACAlgorithm/HS256
   *
   * @param secret identifier of the secret
   * @return Algorithm
   */
  public static Algorithm HMAC256(String secret) {
    return new HMACAlgorithm("HS256", "HmacSHA256", secret.getBytes(StandardCharsets.UTF_8));
  }

  /**
   * Factory constructor for an HMACAlgorithm/HS384
   *
   * @param secret identifier of the secret
   * @return Algorithm
   */
  public static Algorithm HMAC384(String secret) {
    return new HMACAlgorithm("HS384", "HmacSHA384", secret.getBytes(StandardCharsets.UTF_8));
  }

  /**
   * Factory constructor for an HMACAlgorithm/HS512
   *
   * @param secret identifier of the secret
   * @return Algorithm
   */
  public static Algorithm HMAC512(String secret) {
    return new HMACAlgorithm("HS512", "HmacSHA512", secret.getBytes(StandardCharsets.UTF_8));
  }

  /**
   * Factory constructor for an RSAAlgorithm/RS256
   *
   * @param keyPair reference to the KeyPair
   * @return Algorithm
   */
  public static Algorithm RSA256(KeyPair keyPair) {
    return new RSAAlgorithm("RS256", "SHA256withRSA", keyPair);
  }

  /**
   * Factory constructor for an RSAAlgorithm/RS384
   *
   * @param keyPair reference to the KeyPair
   * @return Algorithm
   */
  public static Algorithm RSA384(KeyPair keyPair) {
    return new RSAAlgorithm("RS384", "SHA384withRSA", keyPair);
  }

  /**
   * Factory constructor for an RSAAlgorithm/RS512
   *
   * @param keyPair reference to the KeyPair
   * @return Algorithm
   */
  public static Algorithm RSA512(KeyPair keyPair) {
    return new RSAAlgorithm("RS512", "SHA512withRSA", keyPair);
  }

  /**
   * Provision to verify the incoming byte[] sdata
   *
   * @param data keyPair reference to the KeyPair
   * @param expected reference to compare to data
   * @return boolean result of the comparison
   * @throws Exception when things go wrong
   */
  public abstract boolean verify(byte[] data, byte[] expected) throws Exception;

  /**
   * Provision to sign the incoming String data
   *
   * @param data incoming String data
   * @return signed byte[] data
   * @throws Exception when things go wrong
   */
  public abstract byte[] sign(String data) throws Exception;

  /**
   * Provision to sign the incoming byte[] data
   *
   * @param data to be signed
   * @return signed byte[] data
   * @throws Exception when things go wrong
   */
  public abstract byte[] sign(byte[] data) throws Exception;

  /** Name of the Algorithm */
  protected final String name;

  /**
   * Access the Algorithm's name
   *
   * @return String name of an algorithm
   */
  public String getName() { return name; }

  /** Description the Algorithm */
  protected final String description;

  /**
   * Publish the Algorithm's description
   *
   * @return String description of an algorithm
   */
  public String getDescription() { return description; }
}
