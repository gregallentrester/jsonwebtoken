package net.greg.jwt;

import java.nio.charset.StandardCharsets;
import java.util.*;

import net.greg.jwt.claims.*;

/**
 * Validates a Token (realtime)
 */
public final class TokenValidator {

  /**
   * A dictionary of Header (Claim) validators
   */
  private final Map<String, ClaimValidator> headerValidators;

  /**
   * A dictionary of Payload (Claim) validators
   */
  private final Map<String, ClaimValidator> payloadValidators;

  /**
   * No-args constructor
   */
  public TokenValidator() {
    this(new Builder().withType("JWT"));
  }

  /**
   * Constructor accepts the content of the internal Builder
   *
   * @param builder constructor accepts an argument of type <code>Builder</code>
   */
  public TokenValidator(Builder builder) {

    this.headerValidators = builder.headerValidators;
    this.payloadValidators = builder.payloadValidators;
  }

  /**
   * Aggregate method calls three worker validation methods
   *
   * @param token the Token to be validated
   * @throws java.lang.Exception when things go wrong
   */
  public final void validate(Token token) throws Exception {

    validateAlgorithm(token);
    verifyValidators(token.getHeader().getAsMap(), headerValidators);
    verifyPayload(token.getPayload());
  }

  /**
   * The Algorithm validation logic
   *
   * @param token Token to be validated
   * @throws java.lang.Exception when things go wrong
   */
  private void validateAlgorithm(Token token) throws Exception {

    String concatenated =
      String.format(
        "%s.%s",
        token.getHeader().base64Encoded(),
        token.getPayload().base64Encoded());

    byte[] concatenatedBytes =
      concatenated.getBytes(StandardCharsets.UTF_8);

    if ( ! token.getAlgorithm().verify(concatenatedBytes, Base64.getUrlDecoder().decode(token.getSignature()))) {
      throw new Exception("Signature is not valid");
    }
  }

  /**
   * The validation logic for Claim Validators
   *
   * @param map map of registered validators
   * @param validators map of validators
   * @throws java.lang.Exception when things go wrong
   */
  private void verifyValidators(
      Map<String, Object> map,
      Map<String, ClaimValidator> validators) throws Exception {

    for (Map.Entry<String, ClaimValidator> validatorEntry : validators.entrySet()) {

      String key =
        validatorEntry.getKey();

      ClaimValidator validator =
        validatorEntry.getValue();

      if ( ! map.containsKey(key)) {
        throw new Exception(key + " is not present in payload");
      }

      if (map.get(key) == null) {
        throw new Exception(key + " is null");
      }

      if ( ! validator.validate(map.get(key))) {
        throw new Exception(key + " does not conform to constraint");
      }
    }
  }

  /**
   * The Payload validation logic
   *
   * @param payload payload to be verified
   * @throws java.lang.Exception when things go wrong
   */
  private void verifyPayload(Payload payload) throws Exception {

    Date currentDate = new Date();

    validateExpirationTime(payload, currentDate);
    validateNotBefore(payload, currentDate);
    verifyValidators(payload.getAsMap(), payloadValidators);
  }

  /**
   * The logic to validate the NotBefore (nbf) Claim
   *
   * @param payload payload to be validated
   * @param currentDate now as a Date
   * @throws java.lang.Exception when things go wrong
   */
  private void validateNotBefore(Payload payload, Date currentDate) throws Exception {

    // Checks that if the not-before (nbf) claim is set,
    // the current date is after or equal to the not-before date.
    if (payload.containsClaim(Claims.Registered.NOT_BEFORE.getValue())) {

      Date notBefore = payload.getNotBefore();

      if ( ! (currentDate.getTime() > notBefore.getTime())) {
        throw new Exception("JWT is only valid after " + notBefore);
      }
    }
  }

  /**
   * The logic to validate the ExpirationTime (exp) Claim
   *
   * @param payload Claim to validate
   * @param currentDate now as a Date
   * @throws java.lang.Exception when things go wrong
   */
  private void validateExpirationTime(Payload payload, Date currentDate) throws Exception {

    if (payload.containsClaim(Claims.Registered.EXPIRATION_TIME.getValue())) {

      Date expirationTime = payload.getExpirationTime();

      if (currentDate.getTime() > expirationTime.getTime()) {
        throw new Exception("JWT expired on " + expirationTime);
      }
    }
  }

  /**
   * The Header validation logic
   *
   * @return Map of registered Header validators
   */
  public final Map<String, ClaimValidator> getHeaderValidators() {
    return new HashMap(headerValidators);
  }

  /**
   * Access the dictionary of Payload Validators
   *
   * @return Map of registered Payload validators
   */
  public final Map<String, ClaimValidator> getPayloadValidators() {
    return new HashMap(payloadValidators);
  }


  /**
   * The Builder instance for the TokenValidator.java class
   */
  public static class Builder {

    /**
     * Internal reference to the dictionary of Header Validators
     */
    private final Map<String, ClaimValidator> headerValidators;

    /**
     * Internal reference to the dictionary of Payload Validators
     */
    private final Map<String, ClaimValidator> payloadValidators;

    /**
     * No-args constructor
     */
    public Builder() {
      this.headerValidators = new HashMap();
      this.payloadValidators = new HashMap();
    }

    /**
     * Validate the 'typ' Claim, involving the Header
     *
     * @param type String
     * @return Builder
     */
    public Builder withType(String type) {
      withHeader(Claims.Registered.TYPE.getValue(), type::equals);
      return this;
    }

    /**
     * Validate the 'cty' Claim, involving the Header
     *
     * @param contenttype String
     * @return Builder
     */
    public Builder withContentType(String contenttype) {
      withHeader(Claims.Registered.CONTENT_TYPE.getValue(), contenttype::equals);
      return this;
    }

    /**
     * Validate the Algorithm ('alg'), involving the Header
     *
     * @param algorithm String
     * @return Builder
     */
    public Builder withAlgorithm(String algorithm) {
      withHeader(Claims.Registered.ALGORITHM.getValue(), algorithm::equals);
      return this;
    }

    /**
     * Validate the 'iss' Claim, no Header involvement
     *
     * @param issuer String
     * @return Builder
     */
    public Builder withIssuer(String issuer) {
      withClaim(Claims.Registered.ISSUER.getValue(), issuer::equals);
      return this;
    }

    /**
     * Validate the 'sub' Claim, no Header involvement
     *
     * @param subject String
     * @return Builder
     */
    public Builder withSubject(String subject) {
      withClaim(Claims.Registered.SUBJECT.getValue(), subject::equals);
      return this;
    }

    /**
     * Validate a single 'aud' Claim, no Header involvement
     *
     * @param audience String[]
     * @return Builder
     */
    public Builder withOneOfAudience(String... audience) {

      withClaim(Claims.Registered.AUDIENCE.getValue(), value -> {

        for (String audienceItem: audience) {

          if (Arrays.asList((Object[]) value).contains(audienceItem)) {
            return true;
          }
        }

        return false;
      });

      return this;
    }

    /**
     * Validate every 'aud' Claim, no Header involvement
     *
     * @param audience String[]
     * @return Builder
     */
    public Builder withAllOfAudience(String... audience) {

      withClaim(Claims.Registered.AUDIENCE.getValue(), value -> {
        String[] values = (String[]) value;
        return Arrays.asList(values).containsAll(Arrays.asList(audience));
      });

      return this;
    }

    /**
     * Validate the 'exp' Claim, no Header involvement
     *
     * @param expirationTime as a Date
     * @return Builder
     */
    public Builder withExpirationTime(Date expirationTime) {
      withClaim(Claims.Registered.EXPIRATION_TIME.getValue(), value ->
      value.equals(expirationTime.getTime()));
      return this;
    }

    /**
     * Validate the 'exp' Claim, no Header involvement
     *
     * @param timeSinceEpoch now, represented as a long scalar value
     * @return Builder
     */
    public Builder withExpirationTime(long timeSinceEpoch) {
      withClaim(Claims.Registered.EXPIRATION_TIME.getValue(), value ->
      value.equals(timeSinceEpoch));
      return this;
    }

    /**
     * Validate the 'nbf' Claim (expressed as a Date), no Header involvement
     *
     * @param notBefore now, represented as a Date value
     * @return Builder
     */
    public Builder withNotBefore(Date notBefore) {
      withClaim(Claims.Registered.NOT_BEFORE.getValue(), value ->
      value.equals(notBefore.getTime()));
      return this;
    }

    /**
     * Validate the 'nbf' Claim (expressed as a Long), no Header involvement
     *
     * @param timeSinceEpoch now, represented as a long scalar value
     * @return Builder
     */
    public Builder withNotBefore(long timeSinceEpoch) {
      withClaim(Claims.Registered.NOT_BEFORE.getValue(), value ->
      value.equals(timeSinceEpoch));
      return this;
    }

    /**
     * Validate the 'iat' Claim (expressed as a Date), no Header involvement
     *
     * @param issuedAt now, represented as a Date value
     * @return Builder
     */
    public Builder withIssuedAt(Date issuedAt) {
      withClaim(Claims.Registered.ISSUED_AT.getValue(), value ->
      value.equals(issuedAt.getTime()));
      return this;
    }

    /**
     * Validate the 'iat' Claim (expressed as a Long), no Header involvement
     *
     * @param timeSinceEpoch now, represented as a long scalar value
     * @return Builder
     */
    public Builder withIssuedAt(long timeSinceEpoch) {
      withClaim(Claims.Registered.ISSUED_AT.getValue(), value ->
      value.equals(timeSinceEpoch));
      return this;
    }

    /**
     * Validate the 'jti' Claim (expressed as a String), no Header involvement
     *
     * @param id of the Claim
     * @return Builder
     */
    public Builder withID(String id) {
      withClaim(Claims.Registered.JWT_ID.getValue(), id::equals);
      return this;
    }

    /**
     * Validate the Header
     *
     * @param name String
     * @param value String
     * @return Builder
     */
    public Builder withHeader(String name, Object value) {
      withHeader(name, value::equals);
      return this;
    }

    /**
     * Validate the Header, w/ custom validator
     *
     * @param name String
     * @param validator custom Claim validator
     * @return Builder
     */
    public Builder withHeader(String name, ClaimValidator validator) {

      if (name == null) { throw new IllegalArgumentException("name cannot be null"); }
      if (validator == null) { throw new IllegalArgumentException("validator cannot be null"); }

      headerValidators.put(name, validator);
      return this;
    }

    /**
     * Validate an opaque Claim
     *
     * @param name String
     * @param value reference to a Claim
     * @return Builder
     */
    public Builder withClaim(String name, Object value) {
      withClaim(name, value::equals);
      return this;
    }

    /**
     * Validate an opaque Claim, w/ custom validator
     *
     * @param name String
     * @param validator custom Claim validator
     * @return Builder
     */
    public Builder withClaim(String name, ClaimValidator validator) {
      if (name == null) { throw new IllegalArgumentException("name cannot be null"); }
      if (validator == null) { throw new IllegalArgumentException("validator cannot be null"); }

      payloadValidators.put(name, validator);
      return this;
    }

    /**
     * The canonical terminal method for the internal Builder
     *
     * @return TokenValidator
     */
    public TokenValidator build() {
      return new TokenValidator(this);
    }
  }
}
