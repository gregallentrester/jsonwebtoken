package net.greg.jwt;

import net.greg.jwt.delegate.*;


/**
  Calls JWT-based routines that model a SUCCESS and a FAIL scenario
  <p>
  A) Model an intentional FAIL by making an attempt w/ a (bearer-token) date value that reflects yesterday (and the NBF Claim reflects today)
  </p>
  <p>
  B) Model an intentional SUCCESS by making an attempt w/ a (bearer-token) date value that reflects tomorrow (and the NBF Claim reflect today)
  </p>
*/
public final class App {

  /**
   * Make delegating calls which model an intentional JWT SUCCESS, followed by an intentional JWT FAIL.
   * @param args entrypoint into a Java standalone app
   * @throws Exception c
   */
  public static void main(String[] args) throws Exception {

    if (args[0].equalsIgnoreCase("VALID")) {
      ClaimsForgeryDetectionDelegate.simulateValidNotBefore();
    }
    else if (args[0].equalsIgnoreCase("INVALID")) {
      ClaimsForgeryDetectionDelegate.simulateInvalidNotBefore();
    }
  }

  /** The console's protected hue */
  public static final String RED = "\033[1;91m";
  /** The console's green hue */
  public static final String GRN = "\033[1;92m";
  /** The console's yellow hue */
  public static final String YLW = "\033[1;93m";
  /** Terminate hue specification */
  public static final String NC = "\u001B[0m";
}
