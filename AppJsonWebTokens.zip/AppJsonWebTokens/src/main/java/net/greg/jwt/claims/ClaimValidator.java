package net.greg.jwt.claims;

/**
 * Participant in majik Class.cast() late-binding operations
 */
public interface ClaimValidator {

  /**
   * Participant in majik Class.cast() late-binding validation operations on Claims
   *
   * @param value the Claim to validate
   * @return boolean outome of thevalidation
   */
  boolean validate(Object value);
}
