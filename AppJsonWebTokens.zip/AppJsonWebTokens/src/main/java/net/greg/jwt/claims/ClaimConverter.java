package net.greg.jwt.claims;

/**
 * Participant in majik Class.cast() late-binding operations
 */
public interface ClaimConverter {

  /**
   * Participant in majik Class.cast() late-binding conversion operations on Claims
   *
   * @param value the Claim to be converted
   * @return Object opaque reference to the found Claim
   */
  Object convert(Object value);
}
