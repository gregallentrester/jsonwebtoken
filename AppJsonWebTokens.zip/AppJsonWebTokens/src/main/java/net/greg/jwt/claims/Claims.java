package net.greg.jwt.claims;

import java.util.*;
import java.util.stream.Collectors;

import org.json.JSONObject;

import net.greg.jwt.utils.Base64Utils;


/**
 * Ancestral (base) class for all legal JWT Claims
 */
public abstract class Claims {

  /**
   * Primitive array of registered, date-centric Claims
   *
   */
  private final Registered[] registeredDateClaims =
    { Registered.EXPIRATION_TIME, Registered.ISSUED_AT, Registered.NOT_BEFORE };

  /**
   * A dictionary of Claims
   */
  protected final Map<String, Object> claims;

  /**
   * No-args, inaccessible constructor
   */
  protected Claims() {
    claims = new HashMap();
  }

  /**
   * Discern whether this is a registered Claim
   *
   * @param name identity of a Claim to be registered
   * @return boolean whether the incoming identifier references a register Claim
   */
  public boolean containsClaim(String name) {
    return claims.containsKey(name);
  }

  /**
   * Get the Map of registered Claims
   *
   * @return Map dictionary of registered Claims
   */
  public Map<String, Object> getAsMap() {
    return new HashMap(claims);
  }

  /**
   * Utility method that encodes registered Claims to a Base64URL
   *
   * @return String the base64-encoded value of this Claim
   */
  public String base64Encoded() {

    String json =
      new JSONObject(claims).toString();

    return Base64Utils.encodeBase64URL(json);
  }


  /**
   * Get a claim by name and cast it to a specific type
   *
   * @param name of the claim
   * @param type of the claim
   * @return  T value cast to specified type
   */
  @SuppressWarnings("unchecked")
  public <T> T getClaim(String name, Class<T> type) {

    Object value = claims.get(name);

    boolean isDateClaim =
      Arrays.
        stream(registeredDateClaims).
          map(Claims.Registered::getValue).
            collect(Collectors.toList()).
              contains(name);

    System.err.println(
      "\nClaims.getClaim()\n" +
      "  name: " + name + "\n" +
      "  type: " + type + "\n" +
      "  eval: " + value + "\n" +
      "  isDateClaim == " + isDateClaim);

    if (isDateClaim) {

      long millisSinceEpoch =
        Long.parseLong(String.valueOf(value));

      System.err.println(
        "  CLAIM: " +
        (T) new Date(millisSinceEpoch) + "\n");

      return (T) new Date(millisSinceEpoch);
    }

    System.err.println(
      "  (type.cast) CLAIM: " +
      type.cast(value) + "\n");

    return type.cast(value);
  }

  /**
   * Retrieve a Claim based upon a specified instance of a ClaimConverter
   *
   * @param name the identifier of Claim to be converted
   * @param converter a custom Claim converted
   * @return Object reference to the Claim, resolved using a custom Claim converter
   */
  public Object getClaim(String name, ClaimConverter converter) {
    return converter.convert(claims.get(name));
  }

  /**
   * Add a Claim to the internally-managed dictionary of Claims
   *
   * @param name identifier of Claim to be added to the internal dictionary of registered Claims
   * @param value reference to the Claim to be added to the internal dictionary of registered Claims
   */
  public void addClaim(String name, Object value) {

    if (name == null) { throw new IllegalArgumentException("'name' cannot be null"); }
    if (value == null) { throw new IllegalArgumentException("'value' cannot be null"); }

    claims.put(name, value);
  }

  /**
   * An enum of legal Claims types
   */
  public enum Registered {
    /** issuer Claim */
    ISSUER("iss"),
    /** subject Claim */
    SUBJECT("sub"),
    /** audience Claim */
    AUDIENCE("aud"),
    /** expirationtime Claim */
    EXPIRATION_TIME("exp"),
    /** notBefore Claim */
    NOT_BEFORE("nbf"),
    /** issuedAt time Claim */
    ISSUED_AT("iat"),
    /** jwt-id Claim */
    JWT_ID("jti"),
    /** type Claim */
    TYPE("typ"),
    /** content-type Claim */
    CONTENT_TYPE("cty"),
    /** algorithm */
    ALGORITHM("alg");

    /**
     * A Claim's value
     */
    private final String value;

    /**
     * Accessor for a Claim's value attribute
     *
     * @return String value in the internal K/V pair
     */
    public String getValue() { return value; }

    /**
     * Internal (inaccessible) enum "constructor"
     *
     * @param identifier the identifier for registered Claim
     */
    Registered(String identifier) { value = identifier; }
  }
}
