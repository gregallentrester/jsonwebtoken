package net.greg.jwt.delegate;

import java.time.Instant;
import java.util.Date;

import net.greg.jwt.algorithms.Algorithm;

import net.greg.jwt.*;

/**
 * Example of a app-wide JWT Claims fraud detector facility
 */
public final class ClaimsForgeryDetectionDelegate {

  /**
   *
   * @throws Exception when the Token could not be created
   */
  public static final void simulateInvalidNotBefore() throws Exception {

    Date notBeforeTomorrowClaim =
      Date.from(Instant.
        now().plusSeconds(
          ONE_DAY_DISPLACEMENT_SECONDS));

    Date todayIsAnInvalidDate =
      Date.from(Instant.now());

    System.err.println(
      RED + "\n\n Expect VIOLATION" +
      " | withInvalidNotBefore_throwsException()" +
      "\n\n -------->>--->>> notBeforeTomorrowDate " + notBeforeTomorrowClaim +
      "\n -------->>--->>>    today " + todayIsAnInvalidDate + "\n\n" + NC);

    Token token =
      new Token.Builder(ALGORITHM_HMAC384).
        withNotBefore(notBeforeTomorrowClaim).build();

    System.err.println(
      "Invalid Token: \n" +
      token + "\n  " +
      token.getAlgorithm() + "\n  " +
      token.getPayload() + "\n  " +
      token.getHeader() + "\n  " +
      token.getSignature() + "\n");

    TokenValidator validator =
      new TokenValidator.Builder().
        withNotBefore(
        notBeforeTomorrowClaim).
          build();

    validator.validate(token);
  }

  /**
   *
   * @throws Exception when the Token could not be created
   */
  public static final void simulateValidNotBefore() throws Exception {

    Date notBeforeTomorrowClaimOK =
      Date.from(
        Instant.now().
          minusSeconds(
            ONE_DAY_DISPLACEMENT_SECONDS));

    Date todayIsValidDate =
      Date.from(Instant.now());

    System.err.println(
      GRN + "\n\n Expect COMPLIANCE" +
      " | withValidNotBefore_noThrow()" +
      "\n\n -------->>--->>> yesterday " + notBeforeTomorrowClaimOK +
      "\n -------->>--->>>     today " + todayIsValidDate + "\n\n" + NC);

    Token token =
      new Token.Builder(ALGORITHM_HMAC384).
        withNotBefore(
          notBeforeTomorrowClaimOK).
            build();

    System.err.println(
      "Valid Token: \n" +
      token + "\n  " +
      token.getAlgorithm() + "\n  " +
      token.getPayload() + "\n  " +
      token.getHeader() + "\n  " +
      token.getSignature() + "\n");

    TokenValidator validator =
      new TokenValidator.Builder().
        withNotBefore(
          notBeforeTomorrowClaimOK).
            build();

    validator.validate(token);
  }


  /** leveraged to shift Claim before/after today by one day's worth of seconds */
  private static final int ONE_DAY_DISPLACEMENT_SECONDS = 86_400;

  /** clear-text label used during algorithm construction */
  private static final String SECRET =
    "secret";

  /** Token type is JWT */
  private static final String JWT =
    "JWT";

  /** algorithm being used is HS384 */
  private static final String ALGO_HS384 =
    "HS384";

  /** algorithm reference */
  private static Algorithm ALGORITHM_HMAC384 =
    Algorithm.HMAC384(SECRET);


  /** The console's protected hue */
  public static final String RED = "\033[1;91m";
  /** The console's green hue */
  public static final String GRN = "\033[1;92m";
  /** The console's yellow hue */
  public static final String YLW = "\033[1;93m";
  /** Terminate hue specification */
  public static final String NC = "\u001B[0m";
}
