package net.greg.jwt.algorithms;

import java.nio.charset.StandardCharsets;
import java.security.*;


/**
 * RSAAlgorithm is a specialzation of the Algorithm abstract/base class.
 */
public final class RSAAlgorithm extends Algorithm {

  /**
   * The KeyPair used by the Algorithm
   */
  private final KeyPair keyPair;

  /**
   * Constructor
   *
   * @param name the Algorithm's name
   * @param desc the Algorithm's description
   * @param keyPr the Algorithm's KeyPair
   */
  RSAAlgorithm(String name, String desc, KeyPair keyPr) {
    super(name, desc);
    keyPair = keyPr;
  }

  /**
   * Sign the combination of the Header and the Payload,
   * producing the final product
   *
   * @param data the data to be signed
   * @throws Exception when things go wrong
   */
  @Override
  public byte[] sign(String data) throws Exception {
    return sign(data.getBytes(StandardCharsets.UTF_8));
  }

  /**
   * data is the byte[] data to be signed
   */
  @Override
  public byte[] sign(byte[] data) throws Exception {

    try {

      final Signature signature =
        Signature.getInstance(description);

      signature.initSign(keyPair.getPrivate());
      signature.update(data);

      return signature.sign();
    }
    catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException e) {
      throw new Exception(e.getMessage());
    }
  }

  /**
   * data is the byte[] data to be verified
   */
  @Override
  public boolean verify(byte[] data, byte[] expected) throws Exception {

    try {

      final Signature signature =
        Signature.getInstance(description);

      signature.initVerify(keyPair.getPublic());
      signature.update(data);

      return signature.verify(expected);
    }
    catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException e) {
      throw new Exception(e.getMessage());
    }
  }
}
