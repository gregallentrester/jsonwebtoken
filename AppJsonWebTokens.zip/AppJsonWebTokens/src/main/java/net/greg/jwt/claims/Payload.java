package net.greg.jwt.claims;

import java.util.*;

import org.json.JSONObject;

import net.greg.jwt.utils.Base64Utils;


/**
 * A Claim of type Payload
 */
public final class Payload extends Claims {

  /**
   * No-args constructor
   */
  public Payload() {  }

  /**
   * Constructor that takes an incoming Map to populate
   * the Claims objec t that is associated with a Token
   *
   * @param map dictionary of Claims to be refistered
   */
  public Payload(Map<String, Object> map) {
    claims.putAll(map);
  }

  /**
   * Create a Payload from the decoded incoming JSON (String),
   * using a JSONObject that creates a dictionary that is
   * then used as an argument to construct the Payload instance
   *
   * @param encodedJSON anyrepresentkioan of a JSON String, decoded into a Payload
   * @return Payload
   */
  public static Payload fromBase64EncodedJSON(String encodedJSON) {

    String decodedJSON =
      Base64Utils.decodeBase64URL(encodedJSON);

    Map<String, Object> map =
      new JSONObject(decodedJSON).toMap();

    return new Payload(map);
  }

  /**
   * Accessor for the issuer (String) Claim attribute
   *
   * @return String
   */
  public String getIssuer() {
    return getClaim(Registered.ISSUER.getValue(), String.class);
  }

  /**
   * Mutator for the issuer (String) Claim attribute
   *
   * @param issuer String
   */
  public void setIssuer(String issuer) {
    addClaim(Registered.ISSUER.getValue(), issuer);
  }

  /**
   * Accessor for the subject (String) Claim attribute
   *
   * @return String
   */
  public String getSubject() {
    return getClaim(Claims.Registered.SUBJECT.getValue(), String.class);
  }

  /**
   * Mutator for the Claim of type 'sub', supplying a String value
   *
   * @param subject String
   */
  public void setSubject(String subject) {
    addClaim(Registered.SUBJECT.getValue(), subject);
  }

  /**
   * Accessor for the audience (String []) Claim attribute
   *
   * @return String[]
   */
  public String[] getAudience() {

    Object audience =
      getClaim(
        Registered.AUDIENCE.getValue(), Object.class);

    if ( ! (audience instanceof Object[])) {

      return new String[] {(String) audience};
    }

    return (String[]) audience;
  }

  /**
   * Mutator supplies a primitive array Claims of type 'aud'
   *
   * @param value primitive array of Strings representing Claims of tyoe 'aud'
   */
  public void setAudience(String... value) {
    addClaim(Registered.AUDIENCE.getValue(), value);
  }

  /**
   * Mutator for the Claim of type 'exp', supplying a long value
   *
   * @param value mutate the Claim of type 'exp', supplying a long value
   */
  public void setExpirationTime(long value) {
    addClaim(Registered.EXPIRATION_TIME.getValue(), value);
  }

  /**
   * Mutator for the Claim of type 'exp', supplying a Date value
   *
   * @param value mutate the Claim of type 'exp', supplying a Date value
   */
  public void setExpirationTime(Date value) {
    setExpirationTime(value.getTime());
  }

  /**
   * Accessor for the expirationTime (Date) Claim attribute
   *
   * @return Date
   */
  public Date getExpirationTime() {
    return getClaim(Registered.EXPIRATION_TIME.getValue(), Date.class);
  }

  /**
   * Mutator for the Claim of type 'nbf', supplying a long value
   *
   * @param value mutate the Claim of type 'nbf', supplying a long value
   */
  public void setNotBefore(long value) {
    addClaim(Registered.NOT_BEFORE.getValue(), value);
  }

  /**
   * Mutator for the Claim of type 'nbf', supplying a Date value
   *
   * @param value mutate the Claim of type 'nbf', supplying a Date value
   */
  public void setNotBefore(Date value) {
    setNotBefore(value.getTime());
  }

  /**
   * Accessor for the notBefore (Date) Claim attribute
   *
   * @return Date
   */
  public Date getNotBefore() {
    return getClaim(Registered.NOT_BEFORE.getValue(), Date.class);
  }

  /**
   * Mutator for the Claim of type 'iat', supplying a long value
   *
   * @param value mutate the Claim of type 'iat', supplying a long value
   */
  public void setIssuedAt(long value) {
    addClaim(Registered.ISSUED_AT.getValue(), value);
  }

  /**
   * Mutator for the Claim of type 'iat', supplying a long value
   *
   * @param value mutate the Claim of type 'iat', supplying a Date value
   */
  public void setIssuedAt(Date value) {
    setIssuedAt(value.getTime());
  }

  /**
   * Accessor for the issuedAt (Date) Claim attribute
   *
   * @return Date
   */
  public Date getIssuedAt() {
    return getClaim(Registered.ISSUED_AT.getValue(), Date.class);
  }

  /**
   * Mutator for the Claim of type 'jti', supplying a String value
   *
   * @param value mutate the Claim of type 'jti', supplying a String value
   */
  public void setID(String value) {
    addClaim(Registered.JWT_ID.getValue(), value);
  }

  /**
   * Accessor for the ID (String) Claim attribute
   *
   * @return String
   */
  public String getID() {
    return getClaim(Registered.JWT_ID.getValue(), String.class);
  }
}
